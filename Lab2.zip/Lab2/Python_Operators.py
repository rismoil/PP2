print(10 + 5)


x = 5
y = 3

print(x - y)

print(x * y)



x = 12
y = 3

print(x / y)


x = 5
y = 2

print(x % y)


x = 2
y = 5

print(x ** y) #same as 2*2*2*2*2


x = 15
y = 2

print(x // y)

#the floor division // rounds the result down to the nearest whole number



x = 5

print(x)


x = 5

x += 3

print(x)



x = 5

x -= 3

print(x)


x = 5

x *= 3

print(x)


x = 5

x /= 3

print(x)


x = 5

x%=3

print(x)


x = 5

x//=3

print(x)


x = 5

x **= 3

print(x)


x = 5

x &= 3

print(x)


x = 5

x |= 3

print(x)


x = 5

x ^= 3

print(x)


x = 5

x >>= 3

print(x)


x = 5

x <<= 3

print(x)


print(x := 3)


print((6 + 3) - (6 + 3))

print(100 + 5 * 3)

print(5 + 4 - 7 + 3)


