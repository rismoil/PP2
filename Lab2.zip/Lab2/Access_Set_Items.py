thisset = {"apple", "banana", "cherry"}

for x in thisset:
  print(x)



thisset = {"apple", "banana", "cherry"}

print("banana" in thisset)


thisset = {"apple", "banana", "cherry"}

print("banana" not in thisset)



