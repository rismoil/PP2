a = "Hello, World!"
print(a.upper())



a = "Hello, World!"
print(a.lower())



a = " Hello, World! "
print(a.strip()) # returns "Hello, World!"



a = "Hello, World!"
print(a.replace("H", "J"))



a = "Hello, World!"
print(a.split(",")) # returns ['Hello', ' World!']



