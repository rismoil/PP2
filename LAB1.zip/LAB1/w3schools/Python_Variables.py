x = 5
y = "Hello, World!"

print(x)
print(y)



z = 4
z = "Sally"
print(z)



x = str(3)
y = int(3)
z = float(3)

print(x)
print(y)
print(z)


x = 5
y = "John"
print(type(x))
print(type(y))



x = "John"
print(x)
#double quotes are the same as single quotes:
x = 'John'
print(x)


a = 4
A = "Sally"

print(a)
print(A)
