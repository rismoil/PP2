a = "Hello"
b = "World"
c = a + b
print(c)



a = "Hello"
b = "World"
c = a + " " + b
print(c)



