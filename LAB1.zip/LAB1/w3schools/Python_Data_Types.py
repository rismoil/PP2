x = 5
print(type(x))


x = memoryview(bytes(5))

#display x:
print(x)

#display the data type of x:
print(type(x)) 


x = {"name" : "John", "age" : 36}

#display x:
print(x)

#display the data type of x:
print(type(x)) 



x = frozenset({"apple", "banana", "cherry"})

#display x:
print(x)

#display the data type of x:
print(type(x)) 



x = 1j

#display x:
print(x)

#display the data type of x:
print(type(x)) 


x = str("Hello World")

#display x:
print(x)

#display the data type of x:
print(type(x)) 


x = bytearray(5)

#display x:
print(x)

#display the data type of x:
print(type(x)) 



x = 20.5

#display x:
print(x)

#display the data type of x:
print(type(x)) 

